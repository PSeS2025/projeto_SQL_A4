# Biblioteca SQL
Repositório contendo modelo lógico e scripts SQL.
